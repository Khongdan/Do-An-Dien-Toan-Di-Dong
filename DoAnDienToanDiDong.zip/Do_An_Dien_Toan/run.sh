#!/bin/bash
# Di chuyển vào thư mục chứa script này
cd "$(dirname "$0")"

javac -d bin src/common/FileInfo.java src/peer/PeerCore.java src/peer/PeerGUI.java src/peer/PeerApp.java

# Chạy chương trình Java
java -cp bin peer.PeerApp

# Tương đương với lệnh pause trên Windows (tùy chọn)
read -p "Nhấn Enter để thoát..."