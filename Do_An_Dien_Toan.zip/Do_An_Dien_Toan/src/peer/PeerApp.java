package peer;

import javax.swing.SwingUtilities;


public class PeerApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PeerGUI gui = new PeerGUI("Ứng Dụng gửi nhận file");
            gui.setVisible(true);
        });
    }
}
