package peer;

import common.FileInfo;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.function.BiConsumer;
import java.util.function.Consumer;


public class PeerCore {

    private ServerSocket serverSocket;
    private boolean isRunning = false;

    // Callback: được gọi khi nhận xong 1 file (truyền tên file và đường dẫn)
    private BiConsumer<String, String> onFileReceived;

    // Callback: được gọi khi có log / thông báo
    private Consumer<String> onLog;

    public void setOnFileReceived(BiConsumer<String, String> callback) {
        this.onFileReceived = callback;
    }

    public void setOnLog(Consumer<String> callback) {
        this.onLog = callback;
    }


    //  PHẦN NHẬN FILE  (chạy Server lắng nghe)


    public void startListening(int port) {
        try {
            serverSocket = new ServerSocket(port);
            isRunning = true;
            log("Đang lắng nghe trên cổng " + port + " ...");
            while (isRunning) {
                Socket socket = serverSocket.accept();
                log("Có kết nối từ: " + socket.getInetAddress().getHostAddress());
                // Mỗi kết nối xử lý trên Thread riêng để nhận song song
                new Thread(() -> handleIncoming(socket)).start();
            }
        } catch (IOException e) {
            if (isRunning) log("Lỗi lắng nghe: " + e.getMessage());
        }
    }

    /** Xử lý nhận dữ liệu từ một kết nối vào */
    private void handleIncoming(Socket socket) {
        try (ObjectInputStream ois = new ObjectInputStream(socket.getInputStream())) {

            // Bước 1: Nhận metadata (tên + kích thước file)
            FileInfo fileInfo = (FileInfo) ois.readObject();
            log("Đang nhận: " + fileInfo.getFileName()
                    + " (" + formatSize(fileInfo.getFileSize()) + ")");

            // Bước 2: Tạo thư mục lưu
            File folder = new File("ReceivedFiles");
            if (!folder.exists()) folder.mkdirs();

            // Bước 3: Ghi dữ liệu vào file
            File saveFile = new File(folder, fileInfo.getFileName());
            // Tránh ghi đè: nếu đã tồn tại thì thêm số
            saveFile = uniqueFile(saveFile);

            try (FileOutputStream fos = new FileOutputStream(saveFile)) {
                byte[] buffer = new byte[8192];
                long totalRead = 0;
                int read;
                while (totalRead < fileInfo.getFileSize()
                        && (read = ois.read(buffer)) != -1) {
                    fos.write(buffer, 0, read);
                    totalRead += read;
                }
            }

            log("✔ Nhận xong: " + saveFile.getName());
            if (onFileReceived != null)
                onFileReceived.accept(fileInfo.getFileName(),
                        saveFile.getAbsolutePath());

        } catch (Exception e) {
            log("Lỗi nhận file: " + e.getMessage());
        } finally {
            try { socket.close(); } catch (IOException ignored) {}
        }
    }

    /** Dừng Server lắng nghe */
    public void stopListening() {
        isRunning = false;
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (Exception ignored) {}
        log("Đã dừng lắng nghe.");
    }

    // ─────────────────────────────────────────────
    //  PHẦN GỬI FILE  (kết nối chủ động đến máy kia)
    // ─────────────────────────────────────────────

    /**
     * Gửi file đến máy kia.
     * @param ip   IP của máy nhận
     * @param port Cổng mà máy kia đang lắng nghe
     * @param file File cần gửi
     * @param bar  Thanh tiến trình hiển thị trên GUI
     * @return true nếu gửi thành công
     */
    public boolean sendFile(String ip, int port, File file, JProgressBar bar) {
        if (file == null || !file.exists()) return false;
        try (Socket socket = new Socket(ip, port);
             FileInputStream fis = new FileInputStream(file);
             ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream())) {

            // Gửi metadata trước
            FileInfo info = new FileInfo();
            info.setFileName(file.getName());
            info.setFileSize(file.length());
            oos.writeObject(info);
            oos.flush();

            // Gửi nội dung file
            byte[] buf = new byte[8192];
            long sent = 0;
            int read;
            while ((read = fis.read(buf)) != -1) {
                oos.write(buf, 0, read);
                sent += read;
                final int percent = (int) ((sent * 100) / file.length());
                SwingUtilities.invokeLater(() -> bar.setValue(percent));
            }
            oos.flush();
            log("✔ Gửi xong: " + file.getName());
            return true;

        } catch (Exception e) {
            log("Lỗi gửi file: " + e.getMessage());
            return false;
        }
    }

    // ─────────────────────────────────────────────
    //  TIỆN ÍCH
    // ─────────────────────────────────────────────

    private void log(String msg) {
        if (onLog != null) onLog.accept(msg);
        else System.out.println(msg);
    }

    public static String getLocalIP() {
        try {
            java.net.DatagramSocket socket = new java.net.DatagramSocket();
            socket.connect(java.net.InetAddress.getByName("8.8.8.8"), 80);
            String ip = socket.getLocalAddress().getHostAddress();
            socket.close();
            return ip;
        } catch (Exception e) {
            return "Không lấy được IP";
        }
    }

    private static String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        return String.format("%.2f MB", bytes / (1024.0 * 1024));
    }

    /** Tạo tên file không trùng: abc.txt → abc(1).txt → abc(2).txt ... */
    private static File uniqueFile(File f) {
        if (!f.exists()) return f;
        String name = f.getName();
        String base = name.contains(".")
                ? name.substring(0, name.lastIndexOf('.')) : name;
        String ext  = name.contains(".")
                ? name.substring(name.lastIndexOf('.')) : "";
        int i = 1;
        File result;
        do { result = new File(f.getParent(), base + "(" + i++ + ")" + ext); }
        while (result.exists());
        return result;
    }
}
