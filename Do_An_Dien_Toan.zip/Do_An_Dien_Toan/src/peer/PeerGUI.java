package peer;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.io.File;


public class PeerGUI extends JFrame {

    private final PeerCore core = new PeerCore();

    // ── Phần NHẬN (lắng nghe) ──
    private final JTextField txtListenPort = new JTextField("8888", 6);
    private final JButton btnStart  = new JButton("▶ Bắt đầu lắng nghe");
    private final JButton btnStop   = new JButton("■ Dừng");
    private final DefaultListModel<String> receivedModel = new DefaultListModel<>();

    // ── Phần GỬI ──
    private final JTextField txtTargetIP   = new JTextField("127.0.0.1", 12);
    private final JTextField txtTargetPort = new JTextField("8888", 6);
    private final JLabel     lblFile       = new JLabel("Chưa chọn file", JLabel.CENTER);
    private final JProgressBar bar         = new JProgressBar(0, 100);
    private final JButton btnChoose = new JButton("📂 Chọn File...");
    private final JButton btnSend   = new JButton("📤 GỬI FILE");
    private File selectedFile;

    // ── Log ──
    private final JTextArea txtLog = new JTextArea(6, 40);

    public PeerGUI(String title) {
        setTitle(title);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        add(buildReceivePanel(), BorderLayout.NORTH);
        add(buildSendPanel(),    BorderLayout.CENTER);
        add(buildLogPanel(),     BorderLayout.SOUTH);

        wireCoreCallbacks();
        wireButtons();

        pack();
        setMinimumSize(new Dimension(480, 560));
        setLocationRelativeTo(null);
        btnStop.setEnabled(false);
    }

    // ─────────────────────────────────────────────
    //  XÂY DỰNG GIAO DIỆN
    // ─────────────────────────────────────────────

    private JPanel buildReceivePanel() {
        JPanel p = new JPanel(new BorderLayout(4, 4));
        p.setBorder(new TitledBorder("📥  NHẬN FILE  (lắng nghe kết nối đến)"));

        // Hàng điều khiển
        JPanel ctrl = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        JLabel lblMyIP = new JLabel("IP máy này: " + PeerCore.getLocalIP());
        lblMyIP.setForeground(new Color(0, 130, 0));
        lblMyIP.setFont(lblMyIP.getFont().deriveFont(Font.BOLD));
        ctrl.add(lblMyIP);
        ctrl.add(Box.createHorizontalStrut(10));
        ctrl.add(new JLabel("Cổng lắng nghe:"));
        ctrl.add(txtListenPort);
        ctrl.add(btnStart);
        ctrl.add(btnStop);

        // Danh sách file đã nhận
        JList<String> lstReceived = new JList<>(receivedModel);
        lstReceived.setVisibleRowCount(4);
        JScrollPane scroll = new JScrollPane(lstReceived);
        scroll.setPreferredSize(new Dimension(0, 80));

        JButton btnOpenFolder = new JButton("📁 Mở thư mục");
        btnOpenFolder.addActionListener(e -> {
            try { Desktop.getDesktop().open(new File("ReceivedFiles")); }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                    "Thư mục chưa tồn tại hoặc chưa nhận file nào!");
            }
        });

        p.add(ctrl,          BorderLayout.NORTH);
        p.add(scroll,        BorderLayout.CENTER);
        p.add(btnOpenFolder, BorderLayout.EAST);
        return p;
    }

    private JPanel buildSendPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(new TitledBorder("📤  GỬI FILE  (kết nối đến máy kia)"));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4, 6, 4, 6);
        c.fill = GridBagConstraints.HORIZONTAL;

        // Hàng 1: IP mục tiêu
        c.gridx = 0; c.gridy = 0; c.weightx = 0;
        p.add(new JLabel("IP máy nhận:"), c);
        c.gridx = 1; c.weightx = 1;
        p.add(txtTargetIP, c);

        // Hàng 2: Cổng mục tiêu
        c.gridx = 0; c.gridy = 1; c.weightx = 0;
        p.add(new JLabel("Cổng máy nhận:"), c);
        c.gridx = 1; c.weightx = 1;
        p.add(txtTargetPort, c);

        // Hàng 3: Nút chọn file
        c.gridx = 0; c.gridy = 2; c.gridwidth = 2;
        p.add(btnChoose, c);

        // Hàng 4: Tên file đã chọn
        c.gridy = 3;
        lblFile.setForeground(Color.DARK_GRAY);
        p.add(lblFile, c);

        // Hàng 5: Thanh tiến trình
        c.gridy = 4;
        bar.setStringPainted(true);
        p.add(bar, c);

        // Hàng 6: Nút gửi
        c.gridy = 5;
        btnSend.setFont(btnSend.getFont().deriveFont(Font.BOLD, 13f));
        btnSend.setBackground(new Color(52, 120, 246));
        btnSend.setForeground(Color.WHITE);
        btnSend.setOpaque(true);
        p.add(btnSend, c);

        return p;
    }

    private JPanel buildLogPanel() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(new TitledBorder("📋  Nhật ký hoạt động"));
        txtLog.setEditable(false);
        txtLog.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 11));
        p.add(new JScrollPane(txtLog), BorderLayout.CENTER);
        return p;
    }

    // ─────────────────────────────────────────────
    //  KẾT NỐI CALLBACK & SỰ KIỆN
    // ─────────────────────────────────────────────

    private void wireCoreCallbacks() {
        // Khi nhận xong file → cập nhật danh sách
        core.setOnFileReceived((name, path) ->
            SwingUtilities.invokeLater(() ->
                receivedModel.insertElementAt("✔ " + name, 0)));

        // Log
        core.setOnLog(msg ->
            SwingUtilities.invokeLater(() -> {
                txtLog.append(msg + "\n");
                txtLog.setCaretPosition(txtLog.getDocument().getLength());
            }));
    }

    private void wireButtons() {
        // Bắt đầu lắng nghe
        btnStart.addActionListener(e -> {
            int port;
            try { port = Integer.parseInt(txtListenPort.getText().trim()); }
            catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Cổng lắng nghe không hợp lệ!");
                return;
            }
            new Thread(() -> core.startListening(port)).start();
            btnStart.setEnabled(false);
            btnStop.setEnabled(true);
            txtListenPort.setEnabled(false);
        });

        // Dừng lắng nghe
        btnStop.addActionListener(e -> {
            core.stopListening();
            btnStart.setEnabled(true);
            btnStop.setEnabled(false);
            txtListenPort.setEnabled(true);
        });

        // Chọn file
        btnChoose.addActionListener(e -> {
            JFileChooser jfc = new JFileChooser();
            if (jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                selectedFile = jfc.getSelectedFile();
                lblFile.setText("Đã chọn: " + selectedFile.getName());
                bar.setValue(0);
            }
        });

        // Gửi file
        btnSend.addActionListener(e -> {
            if (selectedFile == null) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn file trước khi gửi!");
                return;
            }
            String ip = txtTargetIP.getText().trim();
            int port;
            try { port = Integer.parseInt(txtTargetPort.getText().trim()); }
            catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Cổng máy nhận không hợp lệ!");
                return;
            }
            final int targetPort = port;
            bar.setValue(0);
            new Thread(() -> {
                SwingUtilities.invokeLater(() -> btnSend.setEnabled(false));
                boolean ok = core.sendFile(ip, targetPort, selectedFile, bar);
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(this,
                        ok ? "Gửi file thành công!" : "Gửi file thất bại!");
                    btnSend.setEnabled(true);
                });
            }).start();
        });
    }
}
