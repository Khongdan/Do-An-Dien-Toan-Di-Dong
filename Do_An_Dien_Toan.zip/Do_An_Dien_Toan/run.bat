@echo off
cd /d "%~dp0"
java -cp bin peer.PeerApp
pause
